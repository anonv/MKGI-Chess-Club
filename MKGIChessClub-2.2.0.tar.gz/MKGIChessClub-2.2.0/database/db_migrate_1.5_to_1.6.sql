alter table mcc_move add `mv_teachermove` varchar(128) character set ascii default NULL
alter table mcc_move add `mv_teacherrate` int(6) default NULL;
alter table mcc_move add `mv_score` int(6) default NULL;
